from flask import Flask, render_template
app = Flask(__name__)
import io
import random
from flask import Response
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from flask import Flask,render_template,request
import pandas as pd
import datetime
from flask import send_file
import new

@app.route('/')

def index():
	return render_template("Project.html")



@app.route('/result',methods=['POST', 'GET'])
@app.route('/plot.png')
def plot_png():
    data = request.form['name']
    sd = request.form['startDate']
    ed = request.form['endDate'] 
    #print(data)
    fig = create_figure(data,sd,ed)
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue(), mimetype='image/png')


@app.route('/result1',methods=['POST', 'GET'])
@app.route('/plot.png')
def plot_png1():
    data = request.form['name1']
    sd = request.form['startDate1']
    ed = request.form['endDate1']   
    fig = create_figure1(data,sd,ed)
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue(), mimetype='image/png')


@app.route('/result2',methods=['POST', 'GET'])
@app.route('/plot.png')
def plot_png2():
    data = request.form['name2']
    sd = request.form['startDate2']
    ed = request.form['endDate2']   
    fig = create_figure2(data,sd,ed)
    output = io.BytesIO()
    FigureCanvas(fig).print_png(output)
    return Response(output.getvalue(), mimetype='image/png')





def create_figure(data,sd,ed):
    fig = Figure()
    axis = fig.add_subplot(1, 1, 1)
    x = pd.read_csv("PhysicalFlows.csv")


# In[15]:


# In[16]:


    l1 = x['DateTime']


# In[17]:


    l2 = x['FlowValue']


    l4 = x['OutAreaName']

# In[18]:
    
    if ed=="":
        ed = str(datetime.datetime.now())
    
    
    l3=[]
    for i in range(len(l2)):
    
    
        
        if l4[i]==data and l1[i]>=sd and l1[i]<=ed :   	    	
            l3.append((l1[i],l2[i]))


# In[19]:


    l3.sort(key=lambda x:x[0])


# In[21]:


    dates = [i[0] for i in l3]
    prices = [i[1] for i in l3]
    import matplotlib.pyplot as plt
    axis.plot(dates, prices)
    axis.set_title("Flow Value = f(Dates) for areaName " + data)
    return fig



def create_figure2(data,sd,ed):
    fig = Figure()
    axis = fig.add_subplot(1, 1, 1)
    x = pd.read_csv("ActualTotalLoad.csv")


# In[15]:


# In[16]:


    l1 = x['DateTime']


# In[17]:


    l2 = x['TotalLoadValue']


    l4 = x['AreaName']

# In[18]:
    
    if ed=="":
        ed = str(datetime.datetime.now())
    
    
    l3=[]
    for i in range(len(l2)):
    
    
        
        if l4[i]==data and l1[i]>=sd and l1[i]<=ed :   	    	
            l3.append((l1[i],l2[i]))


# In[19]:


    l3.sort(key=lambda x:x[0])


# In[21]:


    dates = [i[0] for i in l3]
    prices = [i[1] for i in l3]
    import matplotlib.pyplot as plt
    axis.plot(dates, prices)
    axis.set_title("Flow Value = f(Dates) for areaName " + data)
    return fig





def create_figure1(data,sd,ed):
    fig = Figure()
    axis = fig.add_subplot(1, 1, 1)
    x = pd.read_csv("AggregatedGenerationPerType.csv")


# In[15]:


# In[16]:


    l1 = x['DateTime']


# In[17]:


    l2 = x['ActualGenerationOutput']


    l4 = x['AreaName']

# In[18]:
    
    if ed=="":
        ed = str(datetime.datetime.now())
    
    
    l3=[]
    for i in range(len(l2)):      
        if l4[i]==data and l1[i]>=sd and l1[i]<=ed:   	    	
            l3.append((l1[i],l2[i]))


# In[19]:


    l3.sort(key=lambda x:x[0])


# In[21]:


    dates = [i[0] for i in l3]
    prices = [i[1] for i in l3]
    import matplotlib.pyplot as plt
    axis.plot(dates, prices)
    axis.set_title("Flow Value = f(Dates) for areaName " + data)
    return fig






if __name__ == "__main__":
	app.run(debug=True)




