import pysftp
host = 'sftp-transparency.entsoe.eu'
port = 22
username = 'leonidas_papadopoulos@outlook.com'
password= 'leonidaspapadopoulos!'
import time

print("Hello")



while True:
	try:
	  conn = pysftp.Connection(host=host,port=port,username=username, password=password)
	  print("connection established successfully")
	except:
	  print('failed to establish connection to targeted server')
	 

	conn.get("/TP_export/AggregatedGenerationPerType_16.1.B_C/2022_04_AggregatedGenerationPerType_16.1.B_C.csv")

	conn.get("/TP_export/PhysicalFlows_12.1.G/2022_04_PhysicalFlows_12.1.G.csv")

	conn.get("/TP_export/ActualTotalLoad_6.1.A/2022_04_ActualTotalLoad_6.1.A.csv")



	import pandas as pd


	# In[42]:


	x = pd.read_csv("2022_04_PhysicalFlows_12.1.G.csv")


	# In[43]:

	# In[44]:

	# In[45]:


	list1=[]


	# In[46]:


	list1.append(x.columns[0].split("\t"))


	# In[47]:

	# In[48]:


	x = x.squeeze()


	# In[49]:

	# In[50]:

	# In[51]:


	for i in range(206096):
	    list1.append(str(x[i]).split("\t"))


	# In[52]:

	# In[53]:


	import csv


	# In[54]:


	my_df = pd.DataFrame(list1)

	my_df.to_csv('PhysicalFlows.csv', index=False, header=False)


	# In[55]:


	x = pd.read_csv("2022_04_AggregatedGenerationPerType_16.1.B_C.csv")


	# In[56]:


	list1=[]
	list1.append(x.columns[0].split("\t"))


	# In[57]:


	x = x.squeeze()


	# In[60]:

	# In[61]:


	for i in range(483156):
	    list1.append(str(x[i]).split("\t"))


	# In[62]:


	my_df = pd.DataFrame(list1)

	my_df.to_csv('AggregatedGenerationPerType.csv', index=False, header=False)


	# In[63]:


	x = pd.read_csv("2022_04_ActualTotalLoad_6.1.A.csv")


	# In[64]:


	list1=[]
	list1.append(x.columns[0].split("\t"))


	# In[65]:


	x=x.squeeze()


	# In[66]:

	# In[67]:


	for i in range(46416):
	    list1.append(str(x[i]).split("\t"))

	my_df = pd.DataFrame(list1)
	
	my_df.to_csv('ActualTotalLoad.csv', index=False, header=False)

	# In[68]:


	my_df.to_csv('ActualTotalLoad', index=False, header=False)
	
	
	
	
	import pandas as pd


# In[14]:


	x = pd.read_csv("PhysicalFlows.csv")


# In[15]:


# In[16]:


	l1 = x['DateTime']


# In[17]:


	l2 = x['FlowValue']


# In[18]:


	l3=[]
	for i in range(len(l2)):
    		l3.append((l1[i],l2[i]))


# In[19]:


	l3.sort(key=lambda x:x[0])


# In[21]:


	dates = [i[0] for i in l3]
	prices = [i[1] for i in l3]
	import matplotlib.pyplot as plt
	plt.plot(dates,prices)

	plt.xlabel("Date till today")
	plt.ylabel("Price")
	plt.title("Dates from "+dates[0]+" to "+dates[-1])
	plt.show()


# In[ ]:
	
	
	
	
	
	
	
	
	
	
	
	time.sleep(3600)

